This is the data.

Each file is a csv with columns for each data set, binned yearly.
The first line of each file is the year.

A quick load into python without any dependencies (csv stuff):

'''python
file = 'NonprofitData-sinai.csv'
f = open(file,'r')
years = map(int,f.readline().rstrip().split(','))
data = [map(float,line.rstrip().split(',')) for line in f]
f.close()

for i in range(len(years)):
  print 'The biggest doation in {0:.0f} is ${1:.2f}'.format(years[i],data[0][i])
'''
